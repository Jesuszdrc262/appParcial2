package com.example.aplicacion

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_product.*
import kotlinx.android.synthetic.main.activity_provider.*

class ProviderActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_provider)


        button6.setOnClickListener {

            if (userProv.text.toString().isEmpty() or emailProv.text.toString().isEmpty() or telProv.text.toString().isEmpty()) {
                Toast.makeText(this@ProviderActivity, "Llene todos los campos", Toast.LENGTH_SHORT)
                    .show()
            } else {

                val url = "https://script.google.com/macros/s/AKfycbyTilPOtbP_a0wnU64l6lrPPvMJ5iFuCEbxtQ-dWOOS5gQ0XcpJ/exec"
                val stringRequest = object : StringRequest(
                    Request.Method.POST, url,
                    Response.Listener {
                        Toast.makeText(this@ProviderActivity, it.toString(), Toast.LENGTH_SHORT).show()
                    },
                    Response.ErrorListener {
                        Toast.makeText(this@ProviderActivity, it.toString(), Toast.LENGTH_SHORT).show()
                    }) {
                    override fun getParams(): MutableMap<String, String> {
                        val params=HashMap<String, String>()
                        params["Usuario"]=userProv.text.toString()
                        params["Correo"]=emailProv.text.toString()
                        params["Telefono"]=telProv.text.toString()
                        return params
                    }
                }
                val queue = Volley.newRequestQueue(this@ProviderActivity)
                queue.add(stringRequest)
            }

        }


        button7.setOnClickListener {
            val backIntent = Intent(this, HomeActivity::class.java)
            startActivity(backIntent)
        }
    }
}
