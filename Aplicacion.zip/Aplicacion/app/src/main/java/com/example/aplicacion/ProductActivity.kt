package com.example.aplicacion

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_product.*
import kotlinx.android.synthetic.main.activity_write.*

class ProductActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product)


        button4.setOnClickListener {
            if (nameProd.text.toString().isEmpty() or descProd.text.toString().isEmpty() or priceProd.text.toString().isEmpty()) {
                Toast.makeText(this@ProductActivity, "Llene todos los campos", Toast.LENGTH_SHORT)
                    .show()
            } else {

                val url = "https://script.google.com/macros/s/AKfycbzfL7eCrsMkfdZTu75-kAC2woLlemwPFysHjx19tuad1Cj30UNb/exec"
                val stringRequest = object : StringRequest(
                    Request.Method.POST, url,
                    Response.Listener {
                        Toast.makeText(this@ProductActivity, it.toString(), Toast.LENGTH_SHORT).show()
                    },
                    Response.ErrorListener {
                        Toast.makeText(this@ProductActivity, it.toString(), Toast.LENGTH_SHORT).show()
                    }) {
                    override fun getParams(): MutableMap<String, String> {
                        val params=HashMap<String, String>()
                        params["Nombre"]=nameProd.text.toString()
                        params["Descripcion"]=descProd.text.toString()
                        params["Precio"]=priceProd.text.toString()
                        return params
                    }
                }
                val queue = Volley.newRequestQueue(this@ProductActivity)
                queue.add(stringRequest)
            }
        }
        button5.setOnClickListener {
            val homeIntent = Intent(this, HomeActivity::class.java)
            startActivity(homeIntent)
        }
    }

}
