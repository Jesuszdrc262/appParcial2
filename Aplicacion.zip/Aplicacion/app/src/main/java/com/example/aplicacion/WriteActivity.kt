package com.example.aplicacion

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_write.*

class WriteActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_write)

        regButton.setOnClickListener {
            if (nameText.text.toString().isEmpty() or ageText.text.toString().isEmpty() or addressText.text.toString().isEmpty()) {
                Toast.makeText(this@WriteActivity, "Llene todos los campos", Toast.LENGTH_SHORT)
                    .show()
            } else {

                val url = "https://script.google.com/macros/s/AKfycbzTTZTBrlCo-LE3skzrvtoElfemiVQYMzV0RMHnG95I6ezn5Bs/exec"
                val stringRequest = object : StringRequest(Request.Method.POST, url,
                    Response.Listener {
                        Toast.makeText(this@WriteActivity, it.toString(), Toast.LENGTH_SHORT).show()
                    },
                    Response.ErrorListener {
                        Toast.makeText(this@WriteActivity, it.toString(), Toast.LENGTH_SHORT).show()
                    }) {
                    override fun getParams(): MutableMap<String, String> {
                        val params=HashMap<String, String>()
                        params["Nombre"]=nameText.text.toString()
                        params["Edad"]=ageText.text.toString()
                        params["Direccion"]=addressText.text.toString()
                        return params
                    }
                }
                val queue = Volley.newRequestQueue(this@WriteActivity)
                queue.add(stringRequest)
            }
        }
        button3.setOnClickListener {
            val homeIntent = Intent(this, HomeActivity::class.java)
            startActivity(homeIntent)
        }
    }
}
