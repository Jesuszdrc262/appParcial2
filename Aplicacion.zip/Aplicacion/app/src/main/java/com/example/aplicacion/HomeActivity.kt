package com.example.aplicacion

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_home.*

enum class ProviderType {
    BASIC,
    GOOGLE
}

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        //Setup


        setup()


    }
    private fun setup() {
        button.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val authIntent = Intent(this, AuthActivity::class.java)
            startActivity(authIntent)
        }
        imageButton.setOnClickListener {
            val homeIntent = Intent(this, WriteActivity::class.java)
            startActivity(homeIntent)
        }
        imageButton4.setOnClickListener {
            val prodIntent = Intent(this, ProductActivity::class.java)
            startActivity(prodIntent)
        }
        imageButton5.setOnClickListener {
            val provIntent = Intent(this, ProviderActivity::class.java)
            startActivity(provIntent)
        }

    }

}
